﻿
Partial Class Administration2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("UserName") = "" Or Session("SecurityGroup") <> 1 Then Response.Redirect("Login.aspx")
        If Not IsPostBack Then
            Me.txtStartDate.Text = String.Format("{0:d}", DateAdd(DateInterval.Month, -1, Now()))
            Me.txtEndDate.Text = String.Format("{0:d}", Now())
            Me.txtDailyReportStartDate.Text = String.Format("{0:d}", Now())
            Me.txtItemStartDate.Text = String.Format("{0:d}", DateAdd(DateInterval.Month, -1, Now()))
            Me.txtItemEndDate.Text = String.Format("{0:d}", Now())
            Me.txtClaimedCashStartDate.Text = String.Format("{0:d}", DateAdd(DateInterval.Month, -1, Now()))
            Me.txtClaimedCashEndDate.Text = String.Format("{0:d}", Now())
            Me.txtClaimReportStartDate.Text = String.Format("{0:d}", DateAdd(DateInterval.Month, -1, Now()))
            Me.txtClaimReportEndDate.Text = String.Format("{0:d}", Now())
        End If
    End Sub
End Class
