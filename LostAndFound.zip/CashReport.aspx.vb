
Partial Class CashReport
    Inherits System.Web.UI.Page

End Class
