Imports System.Data.SqlClient
Imports System.Data

Partial Class ClaimItems
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("UserName") = "" Or Session("SecurityGroup") <> 1 Then Response.Redirect("Login.aspx")

        If Not Page.IsPostBack Then
            hfUsername.Value = Session("UserName")

            If Request.QueryString("ID") <> "" Then
                If Request.QueryString("FoundID") <> "" Then
                    Session("FoundID") = "yes"
                    Session("ItemID") = "no"
                Else
                    Session("ItemID") = "yes"
                    Session("FoundID") = "no"
                End If
                LoadRecord(Request.QueryString("ID"))
                sFillItemGridview(Request.QueryString("ID"))
                Exit Sub
            End If

            sFillGridview()
            Me.pnlViewDetail.Visible = False
            Me.txtFromDate.Text = String.Format("{0:d}", DateAdd(DateInterval.Day, -7, Now()))
            Me.txtToDate.Text = String.Format("{0:d}", Now())
        End If

        Me.pnlDisplayAlert.Visible = False
        Me.pnlDisplaySave.Visible = False

    End Sub
    Private Sub LoadRecord(ByVal iID As Integer)
        'Load the record
        Try
            Dim iFoundID As Integer = 0

            Session("ID") = iID
            If Session("FoundID") = "yes" Then
                sSQL = "SELECT * FROM dbo.vwUnclaimedList WHERE FoundID = " & iID
            ElseIf Request.QueryString("ItemID") = "yes" Then
                sSQL = "SELECT * FROM dbo.vwUnclaimedList WHERE ID = " & iID
            End If

            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()

            Dim dr As SqlDataReader

            dr = oComm.ExecuteReader()

            Do While dr.Read()
                If Not IsDBNull(dr("FoundID")) Then
                    iFoundID = dr("FoundID")
                End If
                If Not IsDBNull(dr("FoundDate")) Then
                    Me.txtFoundDate.Text = String.Format("{0:d}", dr("FoundDate"))
                End If
                If Not IsDBNull(dr("RouteNo")) Then
                    Me.txtRoute.Text = dr("RouteNo").ToString()
                End If
                If Not IsDBNull(dr("BusNo")) Then
                    Me.txtBusNumber.Text = dr("BusNo").ToString()
                End If
                If Not IsDBNull(dr("BadgeNumber")) Then
                    Me.txtBadgeNumber.Text = dr("BadgeNumber").ToString()
                End If
                If Not IsDBNull(dr("Base")) Then
                    Me.txtBase.Text = dr("Base").ToString()
                End If
                If Not IsDBNull(dr("EnteredBy")) Then
                    Me.txtEnteredBy.Text = dr("EnteredBy").ToString()
                End If
                If Not IsDBNull(dr("EnteredDate")) Then
                    Me.txtEnteredDate.Text = String.Format("{0:d}", dr("EnteredDate"))
                End If
                If Not IsDBNull(dr("ReceivedDate")) Then
                    Me.txtReceivedDate.Text = String.Format("{0:d}", dr("ReceivedDate"))
                End If
                If Not IsDBNull(dr("ReceivedBy")) Then
                    Me.txtReceivedBy.Text = dr("ReceivedBy").ToString()
                End If
                If Not IsDBNull(dr("Name")) Then
                    Me.txtName.Text = dr("Name").ToString()
                End If
                If Not IsDBNull(dr("Address")) Then
                    Me.txtAddress.Text = dr("Address").ToString()
                End If
                If Not IsDBNull(dr("City")) Then
                    Me.txtCity.Text = dr("City").ToString()
                End If
                If Not IsDBNull(dr("State")) Then
                    Me.txtState.Text = dr("State").ToString()
                End If
                If Not IsDBNull(dr("ZIP")) Then
                    Me.txtZIP.Text = dr("ZIP").ToString()
                End If
                If Not IsDBNull(dr("Phone")) Then
                    Me.txtPhone.Text = dr("Phone").ToString()
                End If
                If Not IsDBNull(dr("Notes")) Then
                    Me.txtNotes.Text = dr("Notes").ToString()
                End If
            Loop

            Me.pnlViewDetail.Visible = True
            Me.Found.InnerHtml = "<span id='Found' runat='server' style='width: 100%; float: left' class='PageTitle'><i class='fa fa-fw fa-tag'></i>FOUND  -  TICKET# <span style='color:#ff6500'>" & iFoundID & "</span></span>"

            oConn.Close()
            oComm = Nothing

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try

    End Sub
    Private Sub sFillGridview()
        'Populate the gridview with data
        Try
            sSQL = "SELECT * FROM vwUnclaimedList WHERE FoundDate BETWEEN '" & Me.txtFromDate.Text & "' AND '" & Me.txtToDate.Text & "' ORDER BY ID"

            Me.txtSQL.Text = sSQL

            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()
            Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            'Check for returned records
            If RcdCount = 0 Then
                gvUnclaimedItems.Visible = False
            Else
                gvUnclaimedItems.Visible = True
                gvUnclaimedItems.DataSource = oDataSet.Tables.Item("dtRecordList")
                gvUnclaimedItems.DataBind()
            End If

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try

    End Sub

    Protected Sub cboTagNo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboTagNo.SelectedIndexChanged
        'Check for index changes and update
        Session("FoundID") = "yes"
        LoadRecord(Me.cboTagNo.SelectedValue)
        sFillItemGridview(Me.cboTagNo.SelectedValue)
        Me.gvUnclaimedItems.Visible = False

    End Sub

    Private Sub sFillItemGridview(ByVal iID As Integer)
        'Populate gridview with items
        Try
            If Session("FoundID") = "yes" Then
                sSQL = "SELECT * FROM dbo.vwItemsClaimed WHERE FoundID =" & iID & " ORDER BY ID"
            Else
                sSQL = "SELECT * FROM dbo.vwItemsClaimed WHERE ID =" & iID & " ORDER BY ID"
            End If

            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()
            Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            'Check for returned records
            If RcdCount = 0 Then
                pnlViewDetail.Visible = False
            Else
                pnlViewDetail.Visible = True
                gvItemsFound.Visible = True
                gvItemsFound.DataSource = oDataSet.Tables.Item("dtRecordList")
                gvItemsFound.DataBind()
            End If

            Session("FoundID") = "no"

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try
    End Sub

    Protected Sub cmdGo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        'Add search filters and criteria to retrieve from database
        Dim sCriteria As String
        Dim dDateFrom As Date
        Dim dDateTo As Date
        Dim MyItem As ListItem
        Dim sText As String

        Try
            sCriteria = ""
            sText = ""
            If Me.txtFromDate.Text = "" Or Me.txtToDate.Text = "" Then
                dDateFrom = String.Format("{0:d}", CDate(DateAdd(DateInterval.Day, -90, Now())))
                dDateTo = String.Format("{0:d}", Now())
                sCriteria = "FoundDate BETWEEN '" & dDateFrom & "' AND '" & dDateTo & "' AND "
            Else
                dDateFrom = CDate(Me.txtFromDate.Text)
                dDateTo = CDate(Me.txtToDate.Text)
                sCriteria = "FoundDate BETWEEN '" & dDateFrom & "' AND '" & dDateTo & "' AND "
            End If

            If Me.txtDescription.Text <> "" Then
                sCriteria = sCriteria & "Description LIKE '%" & Trim(Me.txtDescription.Text) & "%' AND "
            End If

            If Me.txtRouteNo.Text <> "" Then
                sCriteria = sCriteria & "RouteNo = " & Trim(Me.txtRouteNo.Text) & " AND "
            End If

            If Me.cboColor.SelectedValue <> "" Then
                sCriteria = sCriteria & "Color = '" & Trim(Me.cboColor.SelectedValue) & "' AND "
            End If

            If Me.txtMake.Text <> "" Then
                sCriteria = sCriteria & "Make = '" & Trim(Me.txtMake.Text) & "' AND "
            End If

            'If Me.txtSerial.Text <> "" Then
            '    sCriteria = sCriteria & "Serial = '" & Trim(Me.txtSerial.Text) & "' AND "
            'End If

            txtSQL.Text = ""
            For Each MyItem In CheckBoxList1.Items
                If MyItem.Selected = True Then
                    sText = sText & "'" & MyItem.Text & "', "
                End If
            Next

            If sText <> Nothing Then
                sText = Left(sText, Len(sText) - 2)
                sCriteria = sCriteria & "ItemCategory IN (" & sText & ") AND "
            End If

            sSQL = "SELECT * FROM dbo.vwUnclaimedList WHERE " & sCriteria

            sSQL = Left(sSQL, Len(sSQL) - 5) & " ORDER BY ID DESC"

            Me.txtSQL.Text = sSQL

            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()
            Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            'Check for returned records
            If RcdCount = 0 Then
                gvUnclaimedItems.Visible = True
                pnlDisplayAlert.Visible = True
            Else
                gvUnclaimedItems.Visible = True
                gvUnclaimedItems.DataSource = oDataSet.Tables.Item("dtRecordList")
                gvUnclaimedItems.DataBind()
            End If

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try
    End Sub

    Protected Sub gvUnclaimedItems_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvUnclaimedItems.Sorting
        'Sort the datagrid
        SortGrid(e.SortExpression)

    End Sub

    Private Sub SortGrid(ByVal sSortField As String)

        'Sort function used to sort the data in the datagrid
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")

        Dim DS As DataSet
        Dim oReader As SqlDataAdapter

        oReader = New SqlDataAdapter(txtSQL.Text, sConn)

        DS = New DataSet
        oReader.Fill(DS, "LoadRecords")

        Dim Source As DataView = DS.Tables("LoadRecords").DefaultView
        Source.Sort = sSortField

        gvUnclaimedItems.DataSource = Source
        gvUnclaimedItems.DataBind()

    End Sub
    Sub GridPageChange(ByVal sender As Object, ByVal e As GridViewPageEventArgs)

        'Function used to page datagrid
        gvUnclaimedItems.PageIndex = e.NewPageIndex

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)

        oConn.Open()

        'Use the SQL staement stored in the txtSQL textbox
        Dim oAdapter As New SqlDataAdapter(txtSQL.Text, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordList")

        Dim RcdCount As String
        RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

        If RcdCount = 0 Then
            gvUnclaimedItems.Visible = False
        Else
            gvUnclaimedItems.Visible = True
            gvUnclaimedItems.DataSource = oDataSet.Tables.Item("dtRecordList")
            gvUnclaimedItems.DataBind()
        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        Try
            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)

            ' Update the record
            oComm.CommandText = "spUpdateClaimed"
            oComm.CommandType = CommandType.StoredProcedure
            oConn.Open()

            Dim iID As SqlParameter = oComm.Parameters.Add("@iID", SqlDbType.Int)
            iID.Value = Session("ID")

            Dim dClaimedDate As SqlParameter = oComm.Parameters.Add("@dClaimedDate", SqlDbType.DateTime)
            dClaimedDate.Value = DateTime.Now.ToString("MM/dd/yyyy")

            Dim cReleasedBy As SqlParameter = oComm.Parameters.Add("@cReleasedBy", SqlDbType.NChar)
            cReleasedBy.Value = CStr(Me.hfUsername.Value)

            Dim cNotes As SqlParameter = oComm.Parameters.Add("@cNotes", SqlDbType.NChar)
            cNotes.Value = CStr(Me.txtNotes.Text)

            Dim cName As SqlParameter = oComm.Parameters.Add("@cName", SqlDbType.NChar)
            cName.Value = CStr(Me.txtName.Text)

            Dim cAddress As SqlParameter = oComm.Parameters.Add("@cAddress", SqlDbType.NChar)
            cAddress.Value = CStr(Me.txtAddress.Text)

            Dim cCity As SqlParameter = oComm.Parameters.Add("@cCity", SqlDbType.NChar)
            cCity.Value = CStr(Me.txtCity.Text)

            Dim cZIP As SqlParameter = oComm.Parameters.Add("@cZIP", SqlDbType.NChar)
            cZIP.Value = CStr(Me.txtZIP.Text)

            Dim cState As SqlParameter = oComm.Parameters.Add("@cState", SqlDbType.NChar)
            cState.Value = CStr(Me.txtState.Text)

            Dim cPhone As SqlParameter = oComm.Parameters.Add("@cPhone", SqlDbType.NChar)
            cPhone.Value = CStr(Me.txtPhone.Text)

            oComm.ExecuteNonQuery()
            oComm.Parameters.Clear()

            oConn.Close()

            ClearForm()
            pnlViewDetail.Visible = False
            Me.pnlDisplaySave.Visible = True
            Me.DisplayClaimID.InnerHtml = "<span id='DisplayClaimID' runat='server'><strong><i class='fa fa-info-circle'></i> Saved!</strong> The Lost Item #" & Session("ID") & " has been claimed.</span>"
            Session("ID") = ""

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try

    End Sub
    Sub ClearForm()

        'Clear and reset the form for a new records entry
        Me.txtFoundDate.Text = ""
        Me.txtRoute.Text = ""
        Me.txtBusNumber.Text = ""
        Me.txtBadgeNumber.Text = ""
        Me.txtBase.Text = ""
        Me.txtEnteredBy.Text = ""
        Me.txtEnteredDate.Text = ""
        Me.txtReceivedDate.Text = ""
        Me.txtReceivedBy.Text = ""
        Me.txtName.Text = ""
        Me.txtAddress.Text = ""
        Me.txtCity.Text = ""
        Me.txtState.Text = ""
        Me.txtZIP.Text = ""
        Me.txtPhone.Text = ""
        Me.txtNotes.Text = ""
        Me.gvUnclaimedItems.Visible = False
        Me.gvItemsFound.Visible = False
        Me.pnlDisplaySave.Visible = False
        Me.pnlDisplayAlert.Visible = False
        Me.pnlViewDetail.ViewStateMode = False
        Session("FoundID") = ""

    End Sub

End Class
