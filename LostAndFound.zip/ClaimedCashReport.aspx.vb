
Partial Class ClaimedCashReport
    Inherits System.Web.UI.Page

End Class
