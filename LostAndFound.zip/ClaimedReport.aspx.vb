
Partial Class ClaimedReport
    Inherits System.Web.UI.Page

End Class
