
Partial Class DailyFoundReport
    Inherits System.Web.UI.Page

End Class
