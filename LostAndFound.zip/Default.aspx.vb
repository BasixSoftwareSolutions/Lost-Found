Imports System.Data.SqlClient
Imports System.Web.UI.WebControls
Imports System.Data

Partial Class [Default]
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        'Put user code to initialize the page here
        If (Session("UserName") = "") Or (Session("SecurityGroup") <> 1 And Session("SecurityGroup") <> 5) Then Response.Redirect("Login.aspx")

        If Not Page.IsPostBack Then
            FillForm()
            BindGrid()
            SetFocus(Me.txtRoute)
            Session("AddRecords") = "False"
            Session("OkToUpdate") = "False"
            Me.txtReportStartDate.Text = String.Format("{0:d}", Now())
        End If
        lblErrorMessage.Visible = False
    End Sub

    Sub FillForm()

        ' default the order date to today
        Me.txtFoundDate.Text = String.Format("{0:d}", Now())
        Me.txtEnteredDate.Text = String.Format("{0:d}", Now())

        txtEnteredBy.Text = Session("UserName")
        ' make the data table for the datagrid
        MakeTable()

    End Sub

    Sub AddRowToTable(ByVal source As Object, ByVal e As EventArgs) Handles cmdAdd.Click
        ' get the table from the session object, add a row to it and put if back
        Dim objDt As New DataTable()

        Try

            Session("AddRecords") = "True"
            Me.lblWarning.Visible = False

            objDt = Session("tbl")

            Dim objDataRow As DataRow

            ' add a row to it
            objDataRow = objDt.NewRow
            objDataRow("ItemCategory") = 0
            objDataRow("Color") = ""
            objDataRow("Make") = ""
            objDataRow("Model") = ""
            'objDataRow("Serial") = ""
            objDataRow("Description") = ""
            objDataRow("Notes") = ""
            objDt.Rows.Add(objDataRow)

            Session("tbl") = objDt
            BindGrid()


        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            Me.lblWarning.InnerHtml = "<span class='warning' ID='lblWarning' style='width:100%; float:left' runat='server' Visible='false'><i class='fa fa-warning'></i> " & ex.Message & "</span>"
            Me.lblWarning.Visible = True
        End Try
    End Sub

    Sub SaveRecord(ByVal source As Object, ByVal e As EventArgs) Handles cmdFoundSave.Click
        Dim intI As Int16
        Dim iID As Integer
        Dim objDt As New DataTable()

        Try
            Me.lblWarning.Visible = False
            If Session("AddRecords") = "False" Or Session("OkToUpdate") = "False" Then
                Me.lblWarning.InnerHtml = "<span class='warning' ID='lblWarning' style='width:100%; float:left' runat='server' Visible='false'><i class='fa fa-warning'></i> No items have been entered for this record!</span>"
                Me.lblWarning.Visible = True
                Exit Sub
            End If

            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)

            oConn.Open()
            ' we need the next Parts order number
            oComm.CommandText = "spGetNextID"
            oComm.CommandType = CommandType.StoredProcedure
            oComm.Connection = oConn
            Dim dr As SqlDataReader
            dr = oComm.ExecuteReader()

            dr.Read()
            iID = CInt(dr(0)) + 1
            dr.Close()

            ' save the order
            oComm.CommandText = "spInsertFound"
            oComm.CommandType = CommandType.StoredProcedure

            Dim dFoundDate As SqlParameter = oComm.Parameters.Add("@dFoundDate", SqlDbType.DateTime)
            dFoundDate.Value = CDate(Me.txtFoundDate.Text)

            Dim iRouteNo As SqlParameter = oComm.Parameters.Add("@iRouteNo", SqlDbType.Int)
            If String.IsNullOrEmpty(Me.txtRoute.Text) Then
                iRouteNo.Value = 9999
            Else
                iRouteNo.Value = CInt(Me.txtRoute.Text)
            End If

            Dim iBusNo As SqlParameter = oComm.Parameters.Add("@iBusNo", SqlDbType.Int)
            If String.IsNullOrEmpty(Me.txtBusNumber.Text) Then
                iBusNo.Value = 9999
            Else
                iBusNo.Value = CInt(Me.txtBusNumber.Text)
            End If

            Dim iBadgeNumber As SqlParameter = oComm.Parameters.Add("@iBadgeNumber", SqlDbType.Int)
            If String.IsNullOrEmpty(Me.txtBadgeNumber.Text) Then
                iBadgeNumber.Value = 9999
            Else
                iBadgeNumber.Value = CInt(Me.txtBadgeNumber.Text)
            End If

            Dim cBase As SqlParameter = oComm.Parameters.Add("@cBase", SqlDbType.Char)
            cBase.Value = Me.cboBase.SelectedItem.Value

            Dim cEnteredBy As SqlParameter = oComm.Parameters.Add("@cEnteredBy", SqlDbType.Char)
            cEnteredBy.Value = Session("UserName")

            Dim dEnteredDate As SqlParameter = oComm.Parameters.Add("@dEnteredDate", SqlDbType.DateTime)
            dEnteredDate.Value = DateTime.Now.ToString("MM/dd/yyyy")

            Dim cNotes As SqlParameter = oComm.Parameters.Add("@cNotes", SqlDbType.Char)
            cNotes.Value = fStripSpecialChar(CStr(Me.txtNotes.Text))

            oComm.ExecuteNonQuery()
            oComm.Parameters.Clear()
            oComm = Nothing
            oConn.Close()

            ' get the found item lines
            objDt = Session("tbl")

            ' walk through and save each line
            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn1 As New SqlConnection(sConn)
            Dim oComm1 As New SqlCommand(sSQL, oConn)

            oConn1.Open()

            oComm1.CommandText = "spInsertItemsFound"
            oComm1.CommandType = CommandType.StoredProcedure
            oComm1.Connection = oConn1
            For intI = 0 To objDt.Rows.Count - 1
                Dim iFoundID As SqlParameter = oComm1.Parameters.Add("@iFoundID", SqlDbType.Int)
                iFoundID.Value = iID

                Dim iItemCategoryID As SqlParameter = oComm1.Parameters.Add("@iItemCategoryID", SqlDbType.Int)
                iItemCategoryID.Value = CInt(objDt.Rows(intI).Item("ItemCategory"))

                Dim cDescription As SqlParameter = oComm1.Parameters.Add("@cDescription", SqlDbType.Char)
                cDescription.Value = fStripSpecialChar(objDt.Rows(intI).Item("Description"))

                Dim cColor As SqlParameter = oComm1.Parameters.Add("@cColor", SqlDbType.NChar)
                cColor.Value = fStripSpecialChar(objDt.Rows(intI).Item("Color"))

                Dim cMake As SqlParameter = oComm1.Parameters.Add("@cMake", SqlDbType.NChar)
                cMake.Value = fStripSpecialChar(objDt.Rows(intI).Item("Make"))

                Dim cModel As SqlParameter = oComm1.Parameters.Add("@cModel", SqlDbType.NChar)
                cModel.Value = fStripSpecialChar(objDt.Rows(intI).Item("Model"))

                'Dim cSerial As SqlParameter = oComm1.Parameters.Add("@cSerial", SqlDbType.NChar)
                'cSerial.Value = fStripSpecialChar(objDt.Rows(intI).Item("Serial"))

                Dim cItemNotes As SqlParameter = oComm1.Parameters.Add("@cNotes", SqlDbType.NChar)
                cItemNotes.Value = fStripSpecialChar(objDt.Rows(intI).Item("Notes"))

                Dim chCreatedBy As SqlParameter = oComm1.Parameters.Add("@chCreatedBy", SqlDbType.Char)
                chCreatedBy.Value = Session("UserName")

                oComm1.ExecuteNonQuery()
                oComm1.Parameters.Clear()
            Next
            oComm1 = Nothing
            oConn1.Close()

            ClearForm()
            Me.lblSuccess.Visible = True
            Me.lblSuccess.InnerHtml = "<span class='success' ID='lblSuccess' style='width:100%; float:left' runat='server' Visible='false'><i class='fa fa-info-circle'></i> Item <span style='color: #ff6500'><b>" & iID & "</b></span> has been saved</span>"


        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            Me.lblWarning.InnerHtml = "<span class='warning' ID='lblWarning' style='width:100%; float:left' runat='server' Visible='false'><i class='fa fa-warning'></i> " & ex.Message & "</span>"
            Me.lblWarning.Visible = True
        End Try
    End Sub

    Sub MakeTable()
        ' create a data table to hold the datagrid order lines
        Dim objDt As New DataTable()
        objDt = New DataTable("ItemsFound")
        With objDt
            .Columns.Add("ItemCategory", GetType(Integer))
            .Columns.Add("Color", GetType(String))
            .Columns.Add("Make", GetType(String))
            .Columns.Add("Model", GetType(String))
            '.Columns.Add("Serial", GetType(String))
            .Columns.Add("Notes", GetType(String))
            .Columns.Add("Description", GetType(String))
        End With
        Session("tbl") = objDt
    End Sub
    Sub BindGrid()
        Dim objDt As New DataTable()

        ' get the datatable with the grid rows
        objDt = Session("tbl")
        GridView1.DataSource = objDt
        GridView1.DataBind()
    End Sub

    ' set focus client script
    Private Sub SetControlFocus(ByVal FocusControl As Control)
        Dim Script As New System.Text.StringBuilder()
        Dim clientID As String = FocusControl.ClientID

        With Script
            .Append("<script language='Javascript'>")
            .Append("document.getElementById('")
            .Append(clientID)
            .Append("').focus();")
            .Append("</script>")
        End With
        ClientScript.RegisterStartupScript(GetType(String), "SetControlFocus", Script.ToString())

    End Sub

    Protected Sub GridView1_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridView1.RowCancelingEdit
        GridView1.EditIndex = -1
        BindGrid()
    End Sub

    Protected Sub GridView1_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridView1.RowEditing
        GridView1.EditIndex = e.NewEditIndex
        BindGrid()
    End Sub

    Protected Sub GridView1_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridView1.RowUpdating
        ' put the new data back in the datatable
        Dim objDt As New DataTable()
        Dim row As GridViewRow = GridView1.Rows(e.RowIndex)

        If CType(row.FindControl("cboItemCategory"), DropDownList).SelectedValue = "0" Then
            lblErrorMessage.Visible = True
            Me.lblErrorMessage.InnerHtml = "<span class='warning' ID='lblErrorMessage' runat='server' Width='100%' Visible='false'><i class='fa fa-warning'></i>You must select an Item Category...</span>"
            Exit Sub
        End If

        If CType(row.FindControl("cboColor"), DropDownList).SelectedValue = "" Then
            lblErrorMessage.Visible = True
            Me.lblErrorMessage.InnerHtml = "<span class='warning' ID='lblErrorMessage' runat='server' Width='100%' Visible='false'><i class='fa fa-warning'></i>You must select a color...</span>"
            Exit Sub
        End If

        If CType(row.FindControl("txtDescription"), TextBox).Text = "" Then
            lblErrorMessage.Visible = True
            Me.lblErrorMessage.InnerHtml = "<span class='warning' ID='lblErrorMessage' runat='server' Width='100%' Visible='false'><i class='fa fa-warning'></i>You must have a desc...</span>"
            Exit Sub
        End If

        ' fill the table from the session object
        objDt = Session("tbl")

        ' update the values in the appropriate row
        objDt.Rows(e.RowIndex).Item("ItemCategory") = CType(row.FindControl("cboItemCategory"), DropDownList).SelectedValue
        objDt.Rows(e.RowIndex).Item("Color") = CType(row.FindControl("cboColor"), DropDownList).SelectedValue
        objDt.Rows(e.RowIndex).Item("Make") = fStripSpecialChar(CType(row.FindControl("txtMake"), TextBox).Text)
        objDt.Rows(e.RowIndex).Item("Model") = fStripSpecialChar(CType(row.FindControl("txtModel"), TextBox).Text)
        'objDt.Rows(e.RowIndex).Item("Serial") = fStripSpecialChar(CType(row.FindControl("txtSerial"), TextBox).Text)
        objDt.Rows(e.RowIndex).Item("Notes") = fStripSpecialChar(CType(row.FindControl("txtNotes"), TextBox).Text)
        objDt.Rows(e.RowIndex).Item("Description") = fStripSpecialChar(CType(row.FindControl("txtDescription"), TextBox).Text)

        ' save the table back to the session
        Session("tbl") = objDt
        ' set the index and rebind
        GridView1.EditIndex = -1
        BindGrid()
        If CType(row.FindControl("cboItemCategory"), DropDownList).SelectedValue > 0 Then
            Session("OkToUpdate") = "True"
        Else
            Session("OkToUpdate") = "False"
        End If

    End Sub

    Sub ClearForm()

        'Clear and reset the form for a new records entry
        Me.txtFoundDate.Text = ""
        Me.txtRoute.Text = ""
        Me.txtBusNumber.Text = ""
        Me.txtBadgeNumber.Text = ""
        Me.cboBase.SelectedIndex = 0
        Me.txtEnteredBy.Text = ""
        Me.txtEnteredDate.Text = ""
        Me.txtNotes.Text = ""
        Me.lblSuccess.Visible = False
        Me.lblWarning.Visible = False

        FillForm()
        BindGrid()
        SetFocus(Me.txtRoute)
        Session("AddRecords") = "False"
        Session("OkToUpdate") = "False"

        txtEnteredBy.Text = Session("UserName")
        Me.txtEnteredDate.Text = String.Format("{0:d}", Now())

    End Sub

    Private Function fStripSpecialChar(ByVal des As String) As String
        Dim sStr As String
        Dim intCounter As Integer
        Dim arrSpecialChar() As String = {"<", ">", "%", "&", "'", "$"}
        sStr = des
        intCounter = 0
        Dim i As Integer
        For i = 0 To arrSpecialChar.Length - 1
            Do Until intCounter = 29
                des = Replace(sStr, arrSpecialChar(i), "")
                intCounter = intCounter + 1
                sStr = des
            Loop
            intCounter = 0
        Next
        If sStr = Nothing Then sStr = ""
        Return sStr
    End Function

End Class
