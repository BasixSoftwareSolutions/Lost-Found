﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Disposition
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("UserName") = "" Or Session("SecurityGroup") <> 1 Then Response.Redirect("Login.aspx")

        If Not (IsPostBack) Then
            Me.cboItemCatergory.Items.Add("All Categories")
        End If
        If Session("Item") <> "" Then
            sdsDispositionList.SelectCommand = "SELECT * FROM vwUnclaimedList WHERE ItemCategory = '" & RTrim(Me.cboItemCatergory.SelectedValue) & "' Order by ItemCategory Desc"
            GridView2.DataBind()
        End If
    End Sub

    Private Sub ItemDisposition(ByVal iID As Integer, ByVal sMode As String)
        Try
            sSQL = "UPDATE dbo.tblItemsFound SET Disposition = '" & sMode & "',  DispositionDate = '" & Now() & "', DispositionBy = '" & Session("UserName") & "' WHERE ID = " & iID & ""

            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)

            ' Update the record
            oComm.CommandText = sSQL
            oComm.CommandType = CommandType.Text
            oConn.Open()

            oComm.ExecuteNonQuery()
            oComm.Parameters.Clear()
            oConn.Close()
            'DataList1.DataSourceID = "sdsDispositionList"
            'DataList1.DataBind()

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try
    End Sub

    Private Sub cboItemCatergory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboItemCatergory.SelectedIndexChanged
        'Check for index changes and update
        If Me.cboItemCatergory.Text = "All Categories" Then
            sdsDispositionList.SelectCommand = "SELECT TOP 100 * FROM vwDispositionList Order by ID"
        Else
            sdsDispositionList.SelectCommand = "SELECT TOP 100 * FROM vwDispositionList WHERE ItemCategory = '" & RTrim(Me.cboItemCatergory.SelectedValue) & "' Order by ID"
        End If
        GridView2.DataBind()
        Session("Item") = RTrim(Me.cboItemCatergory.SelectedValue)
    End Sub
End Class