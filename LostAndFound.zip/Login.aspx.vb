﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Login
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Dim sNTUser As String
            Dim iPos As Integer
            Dim iSecurityGroup As Integer
            Dim bValidUser As Boolean = 0

            sNTUser = System.Web.HttpContext.Current.User.Identity.Name
            iPos = Len(sNTUser) - InStr(1, sNTUser, "\", 1)
            sNTUser = Right(sNTUser, iPos)
            Session("UserName") = sNTUser

            If sNTUser <> "" Then
                'Get the security level of the user
                sSQL = "SELECT SecurityGroup FROM tblUsers WHERE RTRIM(UserName) = '" & Trim(sNTUser) & "' AND Active = 1"
                sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
                Dim oConn As New SqlConnection(sConn)
                Dim oComm As New SqlCommand(sSQL, oConn)
                oComm.CommandType = CommandType.Text

                oConn.Open()

                Dim dr As SqlDataReader

                dr = oComm.ExecuteReader()

                Do While dr.Read()
                    iSecurityGroup = dr("SecurityGroup")
                    Session("SecurityGroup") = iSecurityGroup
                    Session("UserName") = sNTUser
                    bValidUser = 1
                Loop

                oConn.Close()
                oComm = Nothing

                If bValidUser Then
                    Response.Redirect("HomePage.aspx")
                End If
            End If
        End If


    End Sub

    Private Sub cmdLogin_Click(sender As Object, e As EventArgs) Handles cmdLogin.Click

        Dim iSecurityGroup As Integer = 0

        'Get the security level of the user
        sSQL = "SELECT SecurityGroup FROM tblUsers WHERE RTRIM(UserName) = '" & Trim(Me.txtUsername.Text) & "' AND Password = '" & Trim(Me.txtPassword.Text) & "' AND Active = 1"
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        Do While dr.Read()
            iSecurityGroup = dr("SecurityGroup")
            Session("SecurityGroup") = iSecurityGroup
            Session("UserName") = Trim(Me.txtUsername.Text)
        Loop

        oConn.Close()
        oComm = Nothing

        If iSecurityGroup <> 0 Then
            Response.Redirect("HomePage.aspx")
        Else
            Me.ErrMessage.Text = "Invalid Username or Password. Try again."
        End If

    End Sub

    Private Sub lbForgotPassword_Click(sender As Object, e As EventArgs) Handles lbForgotPassword.Click
        Dim sPassword As String = ""
        Dim sEmailAddress As String = ""

        If Trim(Me.txtUsername.Text) = "" Then
            Me.ErrMessage.Text = "Please provide a user name."
            Exit Sub
        End If

        sSQL = "spSendForgottenPassword"
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.StoredProcedure

        Dim vchUserName As New SqlParameter("@vchUserName", SqlDbType.VarChar, 36)
        oComm.Parameters.Add(vchUserName)
        vchUserName.Direction = ParameterDirection.Input
        vchUserName.Value = Trim(Me.txtUsername.Text)

        Dim vchReturnMsg As New SqlParameter("@vchReturnMsg", SqlDbType.VarChar, 36)
        oComm.Parameters.Add(vchReturnMsg)
        vchReturnMsg.Direction = ParameterDirection.Output

        Dim vchReturnedPassword As New SqlParameter("@vchReturnedPassword", SqlDbType.VarChar, 36)
        oComm.Parameters.Add(vchReturnedPassword)
        vchReturnedPassword.Direction = ParameterDirection.Output

        Dim vchEmailAddress As New SqlParameter("@vchEmailAddress", SqlDbType.VarChar, 64)
        oComm.Parameters.Add(vchEmailAddress)
        vchEmailAddress.Direction = ParameterDirection.Output

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        If Convert.IsDBNull(oComm.Parameters("@vchReturnedPassword").Value) Then
            Me.ErrMessage.Text = "Unable to find user name. Try again or contact the IS Helpdesk at ext. 5545."
        Else
            sPassword = RTrim(oComm.Parameters("@vchReturnedPassword").Value)
            sEmailAddress = RTrim(oComm.Parameters("@vchEmailAddress").Value)
            Me.ErrMessage.Text = "Your password has been emailed to you."
        End If

        oConn.Close()
        oComm = Nothing

    End Sub
End Class