﻿Imports System.Data.SqlClient
Imports System.IO
Imports ClosedXML.Excel
Imports System.Data
Imports System.Configuration

Public Class Lost
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            If (Session("UserName") = "") Or (Session("SecurityGroup") <> 1 And Session("SecurityGroup") <> 10) Then Response.Redirect("Login.aspx")

            If Not (IsPostBack) Then
                If Request.QueryString("NewItem") = "yes" Then
                    Me.mpeAddItem.Show()
                End If
                pnlMatches.Visible = False
                pnlDetailView.Visible = False
                Me.txtDateFrom.Text = DateAdd(DateInterval.Day, -120, Date.Today()).ToShortDateString
                Me.txtDateTo.Text = Date.Today.ToShortDateString
                Me.ddlFilterByStatus.SelectedIndex = 1
                Me.cboInquiryMethod.SelectedIndex = 1
                Me.ddlLostPageSize.SelectedValue = 100
            End If

            lblWarning.Visible = False
            lblSuccess.Visible = False

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            Me.lblWarning.InnerHtml = "<span class='warning' ID='lblWarning' runat='server' Width='100%' Visible='false'><i class='fa fa-warning'></i>" & ex.Message & "</span>"
            Me.lblWarning.Visible = True
        End Try

    End Sub

    Private Sub cmdLostSave_Click(sender As Object, e As EventArgs) Handles cmdLostSave.Click
        Try
            Me.lblWarning.Visible = False

            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)
            oConn.Open()

            ' save the order
            oComm.CommandText = "spInsertLost"
            oComm.CommandType = CommandType.StoredProcedure

            Dim dLostDate As SqlParameter = oComm.Parameters.Add("@dLostDate", SqlDbType.DateTime)
            dLostDate.Value = CDate(Me.txtLostDate.Text)

            Dim cFirstName As SqlParameter = oComm.Parameters.Add("@cFirstName", SqlDbType.Char)
            cFirstName.Value = fStripSpecialChar(CStr(Me.txtFirstName.Text))

            Dim cLastName As SqlParameter = oComm.Parameters.Add("@cLastName", SqlDbType.Char)
            cLastName.Value = fStripSpecialChar(CStr(Me.txtLastName.Text))

            Dim cInquiryMethod As SqlParameter = oComm.Parameters.Add("@cInquiryMethod", SqlDbType.Char)
            cInquiryMethod.Value = CStr(Me.cboInquiryMethod.SelectedItem.Value)

            Dim cPhoneNum As SqlParameter = oComm.Parameters.Add("@cPhoneNum", SqlDbType.Char)
            cPhoneNum.Value = fStripSpecialChar(CStr(Me.txtPhone.Text))

            Dim cEmail As SqlParameter = oComm.Parameters.Add("@cEmail", SqlDbType.Char)
            cEmail.Value = fStripSpecialChar(CStr(Me.txtAddEmail.Text))

            Dim cItemCategory As SqlParameter = oComm.Parameters.Add("@cItemCategory", SqlDbType.Char)
            cItemCategory.Value = CStr(Me.cboItemCategory.SelectedItem.Text)

            Dim cColor As SqlParameter = oComm.Parameters.Add("@cColor", SqlDbType.Char)
            cColor.Value = CStr(Me.cboColor.SelectedItem.Value)

            Dim cMake As SqlParameter = oComm.Parameters.Add("@cMake", SqlDbType.Char)
            cMake.Value = fStripSpecialChar(CStr(Me.txtMake.Text))

            Dim cModel As SqlParameter = oComm.Parameters.Add("@cModel", SqlDbType.Char)
            cModel.Value = fStripSpecialChar(CStr(Me.txtModel.Text))

            'Dim cSerialNum As SqlParameter = oComm.Parameters.Add("@cSerialNum", SqlDbType.Char)
            'cSerialNum.Value = fStripSpecialChar(CStr(Me.txtSerial.Text))

            Dim cService As SqlParameter = oComm.Parameters.Add("@cService", SqlDbType.Char)
            cService.Value = Me.cboService.SelectedItem.Value

            Dim iRouteNo As SqlParameter = oComm.Parameters.Add("@cRouteNo", SqlDbType.Char)
            If String.IsNullOrEmpty(Me.txtRoute.Text) Then
                iRouteNo.Value = "9999"
            Else
                iRouteNo.Value = CStr(Me.txtRoute.Text)
            End If

            'Dim cRouteDir As SqlParameter = oComm.Parameters.Add("@cRouteDir", SqlDbType.Char)
            'cRouteDir.Value = Me.cboRouteDir.SelectedItem.Value

            Dim cDescription As SqlParameter = oComm.Parameters.Add("@cDescription", SqlDbType.Char)
            cDescription.Value = fStripSpecialChar(CStr(Me.txtDescription.Text))

            Dim cNotes As SqlParameter = oComm.Parameters.Add("@cNotes", SqlDbType.Char)
            cNotes.Value = fStripSpecialChar(CStr(Me.txtNotes.Text))

            Dim cCreatedBy As SqlParameter = oComm.Parameters.Add("@cCreatedBy", SqlDbType.Char)
            cCreatedBy.Value = Session("UserName")

            oComm.ExecuteNonQuery()
            oComm.Parameters.Clear()
            oComm = Nothing
            oConn.Close()

            ClearForm()

            gvItemsLost.DataBind()

            lblSuccess.Visible = True
            Me.lblSuccess.InnerHtml = "<span Class='success' ID='lblSuccess' runat='server' Width='100%' visible='false'><i class='fa fa-info-circle'></i> Lost Item Info has been saved...</span>"

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            Me.lblWarning.InnerHtml = "<span class='warning' ID='lblWarning' runat='server' Width='100%' Visible='false'><i class='fa fa-warning'></i>" & ex.Message & "</span>"
            Me.lblWarning.Visible = True
        End Try
    End Sub

    Private Function fStripSpecialChar(ByVal des As String) As String
        Dim sStr As String
        Dim intCounter As Integer
        Dim arrSpecialChar() As String = {"<", ">", "%", "&", "'", "$"}
        sStr = des
        intCounter = 0
        Dim i As Integer
        For i = 0 To arrSpecialChar.Length - 1
            Do Until intCounter = 29
                des = Replace(sStr, arrSpecialChar(i), "")
                intCounter = intCounter + 1
                sStr = des
            Loop
            intCounter = 0
        Next
        If sStr = Nothing Then sStr = ""
        Return sStr
    End Function

    Sub ClearForm()

        'Clear and reset the form for a new records entry
        Me.txtLostDate.Text = ""
        Me.txtFirstName.Text = ""
        Me.txtAddEmail.Text = ""
        Me.txtPhone.Text = ""
        Me.cboColor.SelectedIndex = 0
        Me.cboItemCategory.SelectedIndex = 0
        Me.txtMake.Text = ""
        Me.txtModel.Text = ""
        'Me.txtSerial.Text = ""
        Me.txtLastName.Text = ""
        Me.txtDescription.Text = ""
        Me.txtNotes.Text = ""
        Me.cboService.SelectedIndex = 0
        'Me.cboRouteDir.SelectedIndex = 0
        Me.txtRoute.Text = ""

    End Sub
    Private Sub gvItemsLost_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvItemsLost.RowCommand

        If e.CommandName = "RemoveCmd" Then
            Call RemoveLostItem(CInt(e.CommandArgument))
        End If

        If e.CommandName = "MatchCmd" Then
            pnlDetailView.Visible = False
            pnlMatches.Visible = True

            Dim arg() As String
            arg = e.CommandArgument.Split(";")
            Dim dLostDate As Date = arg(0)
            Dim sItemCategory As String = arg(1)
            Dim iID As String = arg(2)

            sSQL = "Select * "
            sSQL = sSQL & "From vwMatchLookup "
            sSQL = sSQL & "Where RTRIM(ItemCategory) = '" & RTrim(sItemCategory) & "' "
            sSQL = sSQL & " AND FoundDate BETWEEN  '" & DateAdd(DateInterval.Day, -3, CDate(dLostDate)) & "' AND '" & DateAdd(DateInterval.Day, 3, CDate(dLostDate)) & "' "
            sSQL = sSQL & "Order By FoundDate DESC"
            sdsPossibleMatches.SelectCommand = sSQL
            GridView2.DataBind()
            Me.spMatchID.InnerHtml = "<span id=""spMatchID"" runat=""server"" style=""color:darkorange""> FOR #" & iID & "</span>"
            Session("LostID") = CInt(iID)
        End If
        If e.CommandName = "EditCmd" Then
            pnlDetailView.Visible = True
            pnlMatches.Visible = False
            sSQL = "Select ID, "
            sSQL = sSQL & "FirstName, "
            sSQL = sSQL & "LastName, "
            sSQL = sSQL & "PhoneNum, "
            sSQL = sSQL & "Email, "
            sSQL = sSQL & "FORMAT(LostDate, 'MM/dd/yyyy') AS LostDate, "
            sSQL = sSQL & "RTrim(ItemCategory) As ItemCategory, "
            sSQL = sSQL & "RTRIM(Color) AS Color, "
            sSQL = sSQL & "Make, "
            sSQL = sSQL & "Model, "
            sSQL = sSQL & "RTRIM(Service) AS Service, "
            sSQL = sSQL & "Route, "
            sSQL = sSQL & "Description, "
            sSQL = sSQL & "Notes, "
            sSQL = sSQL & "Status, "
            sSQL = sSQL & "FoundItemID, "
            sSQL = sSQL & "CreatedBy, "
            sSQL = sSQL & "CreatedDate, "
            sSQL = sSQL & "InquiryMethodID "
            sSQL = sSQL & "From tblLost "
            sSQL = sSQL & "Where Active = 1 "
            sSQL = sSQL & " AND ID = " & CInt(e.CommandArgument) & " "
            sSQL = sSQL & "Order By LostDate DESC"
            Session("LostID") = CInt(e.CommandArgument)
            sdsLostItemsForm.SelectCommand = sSQL
            FormView1.DataBind()
            FormView1.ChangeMode(FormViewMode.Edit)
            FormView1.Enabled = "True"
            'ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "getModal();", True)
        End If
        If e.CommandName = "ViewCmd" Then
            pnlDetailView.Visible = True
            pnlMatches.Visible = False
            sSQL = "Select ID, "
            sSQL = sSQL & "FirstName, "
            sSQL = sSQL & "LastName, "
            sSQL = sSQL & "PhoneNum, "
            sSQL = sSQL & "Email, "
            sSQL = sSQL & "FORMAT(LostDate, 'MM/dd/yyyy') AS LostDate, "
            sSQL = sSQL & "RTrim(ItemCategory) As ItemCategory, "
            sSQL = sSQL & "RTRIM(Color) AS Color, "
            sSQL = sSQL & "Make, "
            sSQL = sSQL & "Model, "
            sSQL = sSQL & "RTRIM(Service) AS Service, "
            sSQL = sSQL & "Route, "
            sSQL = sSQL & "Description, "
            sSQL = sSQL & "Status, "
            sSQL = sSQL & "FoundItemID, "
            sSQL = sSQL & "Notes, "
            sSQL = sSQL & "CreatedBy, "
            sSQL = sSQL & "CreatedDate, "
            sSQL = sSQL & "InquiryMethodID "
            sSQL = sSQL & "From tblLost "
            sSQL = sSQL & "Where Active = 1 "
            sSQL = sSQL & " AND ID = " & CInt(e.CommandArgument) & " "
            sSQL = sSQL & "Order By LostDate DESC"
            Session("LostID") = CInt(e.CommandArgument)
            sdsLostItemsForm.SelectCommand = sSQL
            FormView1.DataBind()
            FormView1.ChangeMode(FormViewMode.ReadOnly)
            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "getModal();", True)
        End If


    End Sub

    Function RemoveLostItem(ByVal iRecordID As Integer) As Boolean
        Try
            RemoveLostItem = False

            sSQL = "UPDATE tblLost SET Active = 0 WHERE ID = " & iRecordID & ""

            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)

            ' Update the record
            oComm.CommandText = sSQL
            oComm.CommandType = CommandType.Text
            oConn.Open()

            oComm.ExecuteNonQuery()
            oComm.Parameters.Clear()
            oConn.Close()

            RemoveLostItem = True
            lblSuccess.Visible = True
            Me.lblSuccess.InnerHtml = "<span Class='success' ID='lblSuccess' runat='server' Width='100%' visible='false'><i class='fa fa-info-circle'></i> Lost Item Info has been removed...</span>"

            gvItemsLost.DataBind()

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            Me.lblWarning.InnerHtml = "<span class='warning' ID='lblWarning' runat='server' Width='100%' Visible='false'><i class='fa fa-warning'></i>" & ex.Message & "</span>"
            Me.lblWarning.Visible = True
            RemoveLostItem = False
        End Try

    End Function

    Private Sub ClosePanel()

        pnlDetailView.Visible = False

    End Sub

    Protected Sub cmdCloseView_Click(sender As Object, e As EventArgs)

        ClosePanel()

    End Sub

    Private Sub FormView1_ItemUpdated(sender As Object, e As FormViewUpdatedEventArgs) Handles FormView1.ItemUpdated

        Try
            gvItemsLost.DataBind()
            pnlDetailView.Visible = True
            pnlMatches.Visible = False
            sSQL = "Select ID, "
            sSQL = sSQL & "FirstName, "
            sSQL = sSQL & "LastName, "
            sSQL = sSQL & "PhoneNum, "
            sSQL = sSQL & "Email, "
            sSQL = sSQL & "FORMAT(LostDate, 'MM/dd/yyyy') AS LostDate, "
            sSQL = sSQL & "RTrim(ItemCategory) As ItemCategory, "
            sSQL = sSQL & "RTRIM(Color) AS Color, "
            sSQL = sSQL & "Make, "
            sSQL = sSQL & "Model, "
            sSQL = sSQL & "RTRIM(Service) AS Service, "
            sSQL = sSQL & "Route, "
            sSQL = sSQL & "Description, "
            sSQL = sSQL & "Notes, "
            sSQL = sSQL & "Status, "
            sSQL = sSQL & "FoundItemID, "
            sSQL = sSQL & "CreatedBy, "
            sSQL = sSQL & "CreatedDate, "
            sSQL = sSQL & "InquiryMethodID "
            sSQL = sSQL & "From tblLost "
            sSQL = sSQL & "Where Active = 1 "
            sSQL = sSQL & " AND ID = " & Session("LostID") & " "
            sSQL = sSQL & "Order By LostDate DESC"
            sdsLostItemsForm.SelectCommand = sSQL
            FormView1.DataBind()
            FormView1.ChangeMode(FormViewMode.ReadOnly)

            lblSuccess.Visible = True
            Me.lblSuccess.InnerHtml = "<span Class='success' ID='lblSuccess' runat='server' Width='100%' visible='false'><i class='fa fa-info-circle'></i> Lost Item record has been updated...</span>"

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            Me.lblWarning.InnerHtml = "<span class='warning' ID='lblWarning' runat='server' Width='100%' Visible='false'><i class='fa fa-warning'></i>" & ex.Message & "</span>"
            Me.lblWarning.Visible = True
        End Try

    End Sub

    Private Sub gvItemsLost_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvItemsLost.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim row As GridViewRow = e.Row
            Dim tp As Label = row.FindControl("lbNotes")
            Dim sNotes As String = CStr(tp.ToolTip)
            Dim lnkEdit As LinkButton = row.FindControl("cmdEdit")
            Dim lnkRemove As LinkButton = row.FindControl("cmdRemove")
            Dim lnkMatch As LinkButton = row.FindControl("cmdMatch")

            'If iStatus = 6 Then
            Dim cell As TableCell
            For Each cell In e.Row.Cells
                'cell.ForeColor = System.Drawing.Color.DodgerBlue
                cell.ToolTip = sNotes
            Next
            'End If

            If Session("SecurityGroup") = 10 Then
                lnkEdit.Visible = False
                lnkMatch.Visible = False
            End If
        End If

    End Sub

    Private Sub ddlLostPageSize_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlLostPageSize.SelectedIndexChanged

        gvItemsLost.PageSize = Convert.ToInt32(ddlLostPageSize.SelectedValue)
        gvItemsLost.DataBind()
        gvItemsLost.PageIndex = 0

    End Sub

    Private Sub lbExportToExcel_Click(sender As Object, e As EventArgs) Handles lbExportToExcel.Click

        Dim dt As New DataTable

        Try
            For Each col As DataControlField In gvItemsLost.Columns
                dt.Columns.Add(col.HeaderText)
            Next

            For Each row As GridViewRow In gvItemsLost.Rows
                Dim nrow As DataRow = dt.NewRow
                Dim z As Integer = 0
                For Each col As DataControlField In gvItemsLost.Columns
                    If z = 15 Then
                        nrow(z) = Trim(row.Cells(z).ToolTip)
                    Else
                        nrow(z) = Trim(row.Cells(z).Text).Replace("&nbsp;", "")
                    End If
                    z += 1
                Next
                dt.Rows.Add(nrow)
            Next

            Using wb As New XLWorkbook()
                wb.Worksheets.Add(dt, "LostItemsList")

                Response.Clear()
                Response.Buffer = True
                Response.Charset = ""
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                Response.AddHeader("content-disposition", "attachment;filename=LostItemsList.xlsx")
                Using MyMemoryStream As New MemoryStream()
                    wb.SaveAs(MyMemoryStream)
                    MyMemoryStream.WriteTo(Response.OutputStream)
                    Response.Flush()
                    Response.End()
                End Using
            End Using

            Exit Sub

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            Me.lblWarning.InnerHtml = "<span class='warning' ID='lblWarning' runat='server' Width='100%' Visible='false'><i class='fa fa-warning'></i>" & ex.Message & "</span>"
            Me.lblWarning.Visible = True
        End Try

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As System.Web.UI.Control)
        ' Verifies that the control is rendered 
        ' No code required here. 
    End Sub

    Private Sub cmdCloseMatch_Click(sender As Object, e As EventArgs) Handles cmdCloseMatch.Click

        pnlMatches.Visible = False

    End Sub

End Class