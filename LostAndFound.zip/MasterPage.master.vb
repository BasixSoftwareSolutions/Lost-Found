Imports System.Data.SqlClient
Imports System.Data
Partial Class MasterPage
    Inherits System.Web.UI.MasterPage
    Dim sSQL As String
    Dim sConn As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim sStr As String
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()

        If Not IsPostBack Then
            Dim sMessage As String

            UserName.InnerHtml = "Welcome back " & Session("UserName")

            If Session("UserName") = "" Then
                Response.Redirect("Login.aspx")
            End If

            Select Case Session("SecurityGroup")
                Case 1
                    'Do nothing
                Case 5
                    Me.lost.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.recieved.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.claimed.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.disposition.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.search.InnerHtml = "<span class='sidebarDisabled'></span>"
                    'Me.administration.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.LostSpan.InnerHtml = "<>"
                Case 10
                    Me.found.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.recieved.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.claimed.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.disposition.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.search.InnerHtml = "<span class='sidebarDisabled'></span>"
                    'Me.administration.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.FoundSpan.InnerHtml = "<>"
                Case Else
                    Me.found.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.lost.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.recieved.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.claimed.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.disposition.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.search.InnerHtml = "<span class='sidebarDisabled'></span>"
                    ' Me.administration.InnerHtml = "<span class='sidebarDisabled'></span>"
                    Me.FoundSpan.InnerHtml = "<>"
                    Me.LostSpan.InnerHtml = "<>"
                    sMessage = "Could not find users credentials for the Lost and Found database"
                    Me.LoginMessage.InnerHtml = "<span runat='server' id='LoginMessage' style='background-color:white; border:solid; color:red'><i class='fa fa-warning'></i> " & sMessage & "</span>"
            End Select

        End If

        Call GetLostCount()

        Select Case Page.GetType().FullName
            Case Is = "ASP.search_aspx"
                sStr = "SEARCH"
                Me.search.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-fw fa-search'></i> Search <i class='fa fa-arrow-left'></i></span>"
            Case Is = "ASP.lost_aspx"
                sStr = "LOST"
                Me.lost.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-comment-o'></i> Lost <i class='fa fa-arrow-left'></i></span>"
            Case Is = "ASP.disposition_aspx"
                sStr = "DISPOSITION"
                Me.disposition.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-upload'></i> Disposition <i class='fa fa-arrow-left'></i></span>"
            Case Is = "ASP.received_aspx"
                sStr = "RECEIVED"
                Me.recieved.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-inbox'></i> Received <i class='fa fa-arrow-left'></i></span>"
            Case Is = "ASP.claimitems_aspx"
                sStr = "CLAIMED"
                Me.claimed.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-fw fa-refresh'></i> Claimed <i class='fa fa-arrow-left'></i></span>"
            Case Is = "ASP.default_aspx"
                sStr = "FOUND"
                Me.found.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-fw fa-tag'></i> Found <i class='fa fa-arrow-left'></i></span>"
            Case Is = "ASP.administration_aspx"
                sStr = "ADMINISTRATION"
                'Me.administration.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-fw fa-user'></i> Administration <i class='fa fa-arrow-left'></i></span>"
            Case Else
                sStr = "LOST & FOUND"
                Me.home.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-fw fa-home'></i> Home <i class='fa fa-arrow-left'></i></span>"
        End Select

    End Sub

    Private Function GetLostCount() As Integer

        GetLostCount = 0

        sSQL = "SELECT Count(ID) AS LostCount FROM dbo.tblLost WHERE Active = 1 AND Status NOT IN(10, 9, 8, 7, 6)"
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        Do While dr.Read()
            GetLostCount = dr("LostCount")
            Me.LostCount.InnerHtml = dr("LostCount")
        Loop

        oConn.Close()
        oComm = Nothing
    End Function

    Private Sub CmdPassword_Click(sender As Object, e As EventArgs) Handles cmdPassword.Click

        Dim pw As String = ""

        sSQL = "SELECT password from dbo.tblUsers WHERE username = '" + Session("UserName") + "'"
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        Do While dr.Read()
            pw = dr("Password")
        Loop

        oConn.Close()
        oComm = Nothing

        If String.Equals((Me.txtOldPass.Text.Trim), (pw.Trim)) Then
            If String.Equals((Me.txtNewPass.Text.Trim), (Me.txtConfirm.Text.Trim)) Then
                sSQL = "UPDATE dbo.tblUsers SET password = '" + Me.txtConfirm.Text.Trim + "' WHERE username = '" + Session("UserName") + "'"
                sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
                Dim oConn2 As New SqlConnection(sConn)
                Dim oComm2 As New SqlCommand(sSQL, oConn2)

                'Update the record
                oComm2.CommandText = sSQL
                oComm2.CommandType = CommandType.Text
                oConn2.Open()

                oComm2.ExecuteNonQuery()
                oComm2.Parameters.Clear()
                oConn2.Close()
                MsgBox("Password has been changed.")
            Else
                Me.errorMsg.Text = "New passwords do not match."
            End If
        Else
            Me.errorMsg.Text = "Old password is incorrect."
        End If

        Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
    End Sub

End Class

