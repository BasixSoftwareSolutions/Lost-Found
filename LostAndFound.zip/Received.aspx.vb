Imports System.Web.UI.WebControls
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Configuration

Partial Class Received
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("UserName") = "" Or Session("SecurityGroup") <> 1 Then Response.Redirect("Login.aspx")

        Me.lblWarning.Visible = False
        If Not IsPostBack Then
            hfUserName.Value = Session("UserName")
            If Request.QueryString("ID") <> "" Then
                pRecordDetail.Visible = True
                ClearForm()
                LoadRecord(Request.QueryString("ID"))
                Session("ID") = Request.QueryString("ID")
            Else
                pRecordDetail.Visible = False
                Session("ID") = Nothing
            End If

            If Session("Base") <> "" And Session("Base") <> "Select Base..." Then
                sSQL = "Select * From [vwItemNotRecevied] WHERE Base = '" & Session("Base") & "' Order By [FoundDate] DESC, [ID] DESC"
                Me.cboBase.Text = Session("Base")
            Else
                sSQL = "Select * From [vwItemNotRecevied] Order By [FoundDate] DESC, [ID] DESC"
            End If

            Me.SqlDataSource1.SelectCommand = sSQL
            GridView2.DataBind()
            GridView2.PageIndex = 0
            Me.ddlPageSize.SelectedValue = 50
        End If

    End Sub

    Private Sub DisplayError(ByVal sMessage As String)

        Me.lblWarning.Text = sMessage
        Me.lblWarning.Visible = True

    End Sub
    Private Sub sLoadTagNo()
        'Load tag number from database
        sSQL = "SELECT [ID] FROM [vwReceivedTagSearchList] ORDER BY [ID] DESC"

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboTagNo.DataSource = oReader
        cboTagNo.DataTextField = "ID"
        cboTagNo.DataValueField = "ID"
        cboTagNo.DataBind()

        oReader.Close()
        oConn.Close()

        'Reset the combobox
        cboTagNo.Items.Insert(0, "Select Tag#")

    End Sub

    Private Sub LoadRecord(ByVal iID As Integer)
        Dim sTag As String

        Try
            'Load the record
            Session("AddRecords") = "False"
            Session("Mode") = ""
            Session("ID") = iID

            sSQL = "SELECT * FROM vwReceivedRecords WHERE ID = " & iID
            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            With oComm.Parameters
                .Add(New SqlParameter("@ID", iID))
            End With

            oConn.Open()

            Dim dr As SqlDataReader
            dr = oComm.ExecuteReader()

            Do While dr.Read()
                If Not IsDBNull(dr("FoundDate")) Then
                    Me.txtFoundDate.Text = String.Format("{0:d}", dr("FoundDate"))
                End If
                If Not IsDBNull(dr("RouteNo")) Then
                    Me.txtRoute.Text = dr("RouteNo").ToString()
                End If
                If Not IsDBNull(dr("BusNo")) Then
                    Me.txtBusNumber.Text = dr("BusNo").ToString()
                End If
                If Not IsDBNull(dr("BadgeNumber")) Then
                    Me.txtBadgeNumber.Text = dr("BadgeNumber").ToString()
                End If
                If Not IsDBNull(dr("Base")) Then
                    Me.txtBase.Text = dr("Base").ToString()
                End If
                If Not IsDBNull(dr("EnteredBy")) Then
                    Me.txtEnteredBy.Text = dr("EnteredBy").ToString()
                End If
                If Not IsDBNull(dr("EnteredDate")) Then
                    Me.txtEnteredDate.Text = String.Format("{0:d}", dr("EnteredDate"))
                End If
                If Not IsDBNull(dr("ReceivedDate")) Then
                    Me.txtReceivedDate.Text = String.Format("{0:d}", dr("ReceivedDate"))
                End If
                If Not IsDBNull(dr("ReceivedBy")) Then
                    Me.txtReceivedBy.Text = dr("ReceivedBy").ToString()
                End If
                If Not IsDBNull(dr("Name")) Then
                    Me.txtName.Text = dr("Name").ToString()
                End If
                If Not IsDBNull(dr("Address")) Then
                    Me.txtAddress.Text = dr("Address").ToString()
                End If
                If Not IsDBNull(dr("City")) Then
                    Me.txtCity.Text = dr("City").ToString()
                End If
                If Not IsDBNull(dr("State")) Then
                    Me.txtState.Text = dr("State").ToString()
                End If
                If Not IsDBNull(dr("ZIP")) Then
                    Me.txtZIP.Text = dr("ZIP").ToString()
                End If
                If Not IsDBNull(dr("Phone")) Then
                    Me.txtPhone.Text = dr("Phone").ToString()
                End If
                If Not IsDBNull(dr("Notes")) Then
                    Me.txtNotes.Text = dr("Notes").ToString()
                End If
                If Not IsDBNull(dr("BinLocation")) Then
                    Me.txtBinLocation.Text = dr("BinLocation").ToString()
                End If
            Loop

            oComm.Parameters.Clear()
            oComm = Nothing
            oConn.Close()

            PopulateItemsFoundGrid(iID)

            sTag = "<span id='FoundTag' runat='server'><i class='fa fa-fw fa-tags'></i> FOUND  -  TICKET# <span style='color:#ff6500'>" & iID & "</span></span>"
            Me.FoundTag.InnerHtml = sTag

            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "getModal();", True)

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            DisplayError("Source: " & ex.Source & " - Error: " & ex.Message)
        End Try

    End Sub

    Sub PopulateItemsFoundGrid(ByVal iID As Integer)
        'Populate items into grid
        Try
            sSQL = "SELECT * FROM dbo.vwItemsClaimed WHERE FoundID =" & iID & ""
            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()
            Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            'Check for returned records
            If RcdCount = 0 Then
                GridView1.Visible = False
            Else
                GridView1.Visible = True
                GridView1.DataSource = oDataSet.Tables.Item("dtRecordList")
                GridView1.DataBind()
                MakeTable()
                Dim dr As SqlDataReader

                dr = oComm.ExecuteReader()
                If dr.HasRows Then
                    Dim objDt As New DataTable()
                    objDt = Session("tbl")
                    Dim objDataRow As DataRow
                    Do While dr.Read()
                        objDataRow = objDt.NewRow
                        objDataRow("ID") = dr("ID")
                        objDataRow("FoundID") = iID
                        objDataRow("ItemCategoryID") = dr("ItemCategoryID")
                        objDataRow("Color") = dr("Color")
                        objDataRow("Make") = dr("Make")
                        objDataRow("Model") = dr("Model")
                        objDataRow("Description") = dr("Description")
                        objDataRow("Notes") = dr("Notes")
                        objDataRow("CashAmt") = dr("CashAmt")
                        objDataRow("Mode") = ""
                        objDt.Rows.Add(objDataRow)
                    Loop
                    Session("tbl") = objDt
                    BindGrid()
                End If
            End If
            oComm = Nothing
            oConn.Close()

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            DisplayError("Source: " & ex.Source & " - Error: " & ex.Message)
        End Try
    End Sub

    Sub MakeTable()
        'Create a data table to hold the datagrid order lines
        Dim objDt As New DataTable()
        objDt = New DataTable("ItemsFound")
        With objDt
            .Columns.Add("ID", GetType(Integer))
            .Columns.Add("FoundID", GetType(Integer))
            .Columns.Add("ItemCategoryID", GetType(Integer))
            .Columns.Add("Color", GetType(String))
            .Columns.Add("Make", GetType(String))
            .Columns.Add("Model", GetType(String))
            .Columns.Add("Notes", GetType(String))
            .Columns.Add("Description", GetType(String))
            .Columns.Add("CashAmt", GetType(Double))
            .Columns.Add("Mode", GetType(String))
        End With
        Session("tbl") = objDt
    End Sub


    Sub AddRowToTable(ByVal source As Object, ByVal e As EventArgs)
        'Get the table from the session object, add a row to it and put if back
        Try
            If Session("ID") = "" Then
                Call DisplayError("You must select a record first!")
                Exit Sub
            End If

            Dim objDt As New DataTable()
            Dim objDataRow As DataRow

            Session("AddRecords") = "True"
            Session("Mode") = "Add"
            objDt = Session("tbl")

            ' add a row to it
            objDataRow = objDt.NewRow
            objDataRow("ID") = 0
            objDataRow("FoundID") = 0
            objDataRow("ItemCategoryID") = 0
            objDataRow("Color") = ""
            objDataRow("Make") = ""
            objDataRow("Model") = ""
            objDataRow("Description") = ""
            objDataRow("Notes") = ""
            objDataRow("CashAmt") = 0
            objDataRow("Mode") = "Add"
            objDt.Rows.Add(objDataRow)

            Session("tbl") = objDt
            BindGrid()
        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            DisplayError("Source: " & ex.Source & " - Error: " & ex.Message)
        End Try

    End Sub

    Private Sub cmdReceivedSave_Click(sender As Object, e As EventArgs) Handles cmdReceivedSave.Click

        Try
            If Request.QueryString("ID") = "" And Me.cboTagNo.SelectedValue = "Select Tag#" Then
                lblSaveMessage.Visible = True
                lblSaveMessage.Text = "No record has been selected"
                Exit Sub
            End If
            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)

            ' Update the record
            oComm.CommandText = "spUpdateFound"
            oComm.CommandType = CommandType.StoredProcedure
            oConn.Open()

            If Request.QueryString("ID") <> "" Then
                Dim iID As SqlParameter = oComm.Parameters.Add("@iID", SqlDbType.Int)
                iID.Value = CInt(Request.QueryString("ID"))
            Else
                Dim iID As SqlParameter = oComm.Parameters.Add("@iID", SqlDbType.Int)
                iID.Value = CInt(Me.cboTagNo.SelectedValue)
            End If

            Dim dReceivedDate As SqlParameter = oComm.Parameters.Add("@dReceivedDate", SqlDbType.DateTime)
            dReceivedDate.Value = DateTime.Now.ToString

            Dim cReceivedBy As SqlParameter = oComm.Parameters.Add("@cReceivedBy", SqlDbType.Char)
            cReceivedBy.Value = Session("UserName")

            Dim dClaimedDate As SqlParameter = oComm.Parameters.Add("@dClaimedDate", SqlDbType.DateTime)
            dClaimedDate.Value = DBNull.Value

            Dim cReleasedBy As SqlParameter = oComm.Parameters.Add("@cReleasedBy", SqlDbType.NChar)
            cReleasedBy.Value = DBNull.Value

            Dim cName As SqlParameter = oComm.Parameters.Add("@cName", SqlDbType.Char)
            cName.Value = fStripSpecialChar(CStr(Me.txtName.Text))

            Dim cAddress As SqlParameter = oComm.Parameters.Add("@cAddress", SqlDbType.Char)
            cAddress.Value = fStripSpecialChar(CStr(Me.txtAddress.Text))

            Dim cCity As SqlParameter = oComm.Parameters.Add("@cCity", SqlDbType.Char)
            cCity.Value = fStripSpecialChar(CStr(Me.txtCity.Text))

            Dim cState As SqlParameter = oComm.Parameters.Add("@cState", SqlDbType.Char)
            cState.Value = CStr(Me.txtState.Text)

            Dim cZIP As SqlParameter = oComm.Parameters.Add("@cZIP", SqlDbType.Char)
            cZIP.Value = CStr(Me.txtZIP.Text)

            Dim cPhone As SqlParameter = oComm.Parameters.Add("@cPhone", SqlDbType.Char)
            cPhone.Value = CStr(Me.txtPhone.Text)

            Dim cNotes As SqlParameter = oComm.Parameters.Add("@cNotes", SqlDbType.Char)
            cNotes.Value = fStripSpecialChar(CStr(Me.txtNotes.Text))

            Dim cBinLocation As SqlParameter = oComm.Parameters.Add("@cBinLocation", SqlDbType.Char)
            cBinLocation.Value = fStripSpecialChar(CStr(Me.txtBinLocation.Text))

            oComm.ExecuteNonQuery()
            oComm.Parameters.Clear()
            oConn.Close()
            SaveItemsFound()

            If Me.cboBase.Text = "Select Base..." Or Session("Base") = "" Then
                sSQL = "Select * From [vwItemNotRecevied] Order By [FoundDate] DESC, [ID] DESC"
            Else
                sSQL = "Select * From [vwItemNotRecevied] WHERE Base = '" & Session("Base") & "' Order By [FoundDate] DESC, [ID] DESC"
            End If

            Me.SqlDataSource1.SelectCommand = sSQL
            pRecordDetail.Visible = False
            GridView2.DataBind()
            Me.cboBase.SelectedValue = Session("Base")
            Session("ID") = Nothing

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            DisplayError("Source: " & ex.Source & " - Error: " & ex.Message)
        End Try

    End Sub

    Sub SaveItemsFound()
        Dim intI As Integer
        Dim objDt As New DataTable()
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)

        Try
            oConn.Open()
            ' get the order lines
            objDt = Session("tbl")

            ' walk through and save each line
            oComm.CommandType = CommandType.StoredProcedure
            oComm.Connection = oConn
            For intI = 0 To objDt.Rows.Count - 1
                If objDt.Rows(intI).Item("FoundID") = 0 Then
                    If objDt.Rows(intI).Item("Mode") = "Add" Then
                        oComm.CommandText = "spInsertItemsFound"
                        Dim iFoundID As SqlParameter = oComm.Parameters.Add("@iFoundID", SqlDbType.Int)
                        iFoundID.Value = CInt(Request.QueryString("ID"))
                    Else
                        oComm.CommandText = "spUpdateItemsFound"
                        Dim iID As SqlParameter = oComm.Parameters.Add("@iID", SqlDbType.Int)
                        iID.Value = objDt.Rows(intI).Item("ID")
                    End If

                    Dim iItemCategoryID As SqlParameter = oComm.Parameters.Add("@iItemCategoryID", SqlDbType.Int)
                    iItemCategoryID.Value = objDt.Rows(intI).Item("ItemCategoryID")

                    Dim cDescription As SqlParameter = oComm.Parameters.Add("@cDescription", SqlDbType.Char)
                    cDescription.Value = fStripSpecialChar(objDt.Rows(intI).Item("Description"))

                    Dim cColor As SqlParameter = oComm.Parameters.Add("@cColor", SqlDbType.Char)
                    cColor.Value = fStripSpecialChar(objDt.Rows(intI).Item("Color"))

                    Dim cMake As SqlParameter = oComm.Parameters.Add("@cMake", SqlDbType.Char)
                    cMake.Value = fStripSpecialChar(objDt.Rows(intI).Item("Make"))

                    Dim cModel As SqlParameter = oComm.Parameters.Add("@cModel", SqlDbType.Char)
                    cModel.Value = fStripSpecialChar(objDt.Rows(intI).Item("Model"))

                    Dim cNotes As SqlParameter = oComm.Parameters.Add("@cNotes", SqlDbType.Char)
                    cNotes.Value = fStripSpecialChar(objDt.Rows(intI).Item("Notes"))

                    Dim chCreatedBy As SqlParameter = oComm.Parameters.Add("@chCreatedBy", SqlDbType.Char)
                    chCreatedBy.Value = Session("UserName")

                    oComm.ExecuteNonQuery()
                    oComm.Parameters.Clear()
                End If
            Next
            oConn.Close()
            Me.FoundTag.InnerHtml = "<span id='Found' runat='server' style='width: 100%; float: left' class='PageTitle'><i class='fa fa-fw fa-tag'></i>FOUND  -  TICKET# <span style='color:#ff6500'>" & Session("ID") & "</span></span>"
            ClearForm()
            Me.lblSaveMessage.Visible = True
            Me.lblSaveMessage.Text = "Record " & Session("ID") & " has been saved."

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            DisplayError("Source: " & ex.Source & " - Error: " & ex.Message)
        End Try

    End Sub

    Sub BindGrid()
        Dim objDt As New DataTable()

        ' get the datatable with the grid rows
        objDt = Session("tbl")
        GridView1.DataSource = objDt
        GridView1.DataBind()
    End Sub

    ' set focus client script
    Private Sub SetControlFocus(ByVal FocusControl As Control)
        Dim Script As New System.Text.StringBuilder()
        Dim clientID As String = FocusControl.ClientID

        With Script
            .Append("<script language='Javascript'>")
            .Append("document.getElementById('")
            .Append(clientID)
            .Append("').focus();")
            .Append("</script>")
        End With
        ClientScript.RegisterStartupScript(GetType(String), "SetControlFocus", Script.ToString())

    End Sub

    Protected Sub GridView1_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridView1.RowCancelingEdit
        GridView1.EditIndex = -1
        BindGrid()
    End Sub

    Protected Sub GridView1_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridView1.RowEditing
        GridView1.EditIndex = e.NewEditIndex
        BindGrid()
    End Sub

    Protected Sub GridView1_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridView1.RowUpdating
        ' put the new data back in the datatable
        Dim objDt As New DataTable()
        Dim row As GridViewRow = GridView1.Rows(e.RowIndex)

        Try
            ' fill the table from the session object
            objDt = Session("tbl")

            ' update the values in the appropriate row
            objDt.Rows(e.RowIndex).Item("FoundID") = 0
            objDt.Rows(e.RowIndex).Item("ItemCategoryID") = CType(row.FindControl("cboItemCategory"), DropDownList).SelectedValue
            objDt.Rows(e.RowIndex).Item("Color") = CType(row.FindControl("cboColor"), DropDownList).SelectedValue
            objDt.Rows(e.RowIndex).Item("Make") = fStripSpecialChar(CType(row.FindControl("txtMake"), TextBox).Text)
            objDt.Rows(e.RowIndex).Item("Model") = fStripSpecialChar(CType(row.FindControl("txtModel"), TextBox).Text)
            objDt.Rows(e.RowIndex).Item("Description") = fStripSpecialChar(CType(row.FindControl("txtDescription"), TextBox).Text)
            objDt.Rows(e.RowIndex).Item("Notes") = fStripSpecialChar(CType(row.FindControl("txtNotes"), TextBox).Text)

            If Session("Mode") = "Add" Then
                objDt.Rows(e.RowIndex).Item("Mode") = "Add"
            Else
                objDt.Rows(e.RowIndex).Item("Mode") = "Update"
            End If
            ' save the table back to the session
            Session("tbl") = objDt
            ' set the index and rebind
            GridView1.EditIndex = -1
            BindGrid()

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            DisplayError("Source: " & ex.Source & " - Error: " & ex.Message)
        End Try

    End Sub

    Sub ClearForm()

        'Clear and reset the form for a new records entry
        Me.txtFoundDate.Text = ""
        Me.txtRoute.Text = ""
        Me.txtBusNumber.Text = ""
        Me.txtBadgeNumber.Text = ""
        Me.txtBase.Text = ""
        Me.txtEnteredBy.Text = ""
        Me.txtEnteredDate.Text = ""
        Me.txtReceivedDate.Text = ""
        Me.txtReceivedBy.Text = ""
        Me.txtName.Text = ""
        Me.txtAddress.Text = ""
        Me.txtCity.Text = ""
        Me.txtState.Text = ""
        Me.txtZIP.Text = ""
        Me.txtPhone.Text = ""
        Me.txtNotes.Text = ""
        Me.txtBinLocation.Text = ""
        Me.GridView1.Visible = False
        Me.lblSaveMessage.Visible = False
        Session("AddRecords") = "False"
        Session("Mode") = ""
        Session("ID") = ""

    End Sub

    Private Function fStripSpecialChar(ByVal des As String) As String
        'Remove special characters from string
        Dim sStr As String
        Dim intCounter As Integer
        Dim arrSpecialChar() As String = {"<", ">", "%", "&", "'"}
        sStr = des
        intCounter = 0
        Dim i As Integer
        For i = 0 To arrSpecialChar.Length - 1
            Do Until intCounter = 29
                des = Replace(sStr, arrSpecialChar(i), "")
                intCounter = intCounter + 1
                sStr = des
            Loop
            intCounter = 0
        Next
        If sStr = Nothing Then sStr = ""
        Return sStr
    End Function

    Protected Sub cboTagNo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboTagNo.SelectedIndexChanged
        'Check for index changes and update
        Session("ID") = Me.cboTagNo.SelectedValue
        LoadRecord(Me.cboTagNo.SelectedValue)
        PopulateItemsFoundGrid(Me.cboTagNo.SelectedValue)

    End Sub

    Private Sub cmdBatchReceivedUpdate_Click(sender As Object, e As EventArgs) Handles cmdBatchReceivedUpdate.Click
        Dim dr As GridViewRow
        Try

            For Each dr In GridView2.Rows
                Dim RowCheckBox As System.Web.UI.WebControls.CheckBox = dr.FindControl("CheckBox2")
                If RowCheckBox.Checked = True Then
                    Dim sUserName As String = hfUserName.Value
                    Dim dToday As DateTime = Now()
                    Dim iRecordID As Integer = GridView2.DataKeys(dr.RowIndex).Values(0)
                    sSQL = "UPDATE tblFound SET ReceivedDate = '" & dToday & "',  ReceivedBy = '" & sUserName & "' WHERE ID = " & iRecordID & ""

                    sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
                    Dim oConn As New SqlConnection(sConn)
                    Dim oComm As New SqlCommand(sSQL, oConn)

                    ' Update the record
                    oComm.CommandText = sSQL
                    oComm.CommandType = CommandType.Text
                    oConn.Open()

                    oComm.ExecuteNonQuery()
                    oComm.Parameters.Clear()
                    oConn.Close()
                End If
            Next

            If Me.cboBase.Text = "Select Base..." Or Session("Base") = "" Then
                sSQL = "Select * From [vwItemNotRecevied] Order By [FoundDate] DESC, [ID] DESC"
            Else
                sSQL = "Select * From [vwItemNotRecevied] WHERE Base = '" & Session("Base") & "' Order By [FoundDate] DESC, [ID] DESC"
            End If

            Me.SqlDataSource1.SelectCommand = sSQL
            pRecordDetail.Visible = False
            GridView2.DataBind()
            Me.cboBase.SelectedValue = Session("Base")
            Session("ID") = Nothing

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            DisplayError("Source: " & ex.Source & " - Error: " & ex.Message)
        End Try
    End Sub

    Private Sub ddlPageSize_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlPageSize.SelectedIndexChanged

        GridView2.PageSize = Convert.ToInt32(ddlPageSize.SelectedValue)
        GridView2.DataBind()
        GridView2.PageIndex = 0

    End Sub

    Private Sub lbExportToExcel_Click(sender As Object, e As EventArgs) Handles lbExportToExcel.Click
        Response.ClearContent()
        Response.Buffer = True
        Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "ReceivedItems.xls"))
        Response.ContentType = "application/ms-excel"

        Dim sw As New StringWriter()
        Dim htw As New HtmlTextWriter(sw)

        GridView2.AllowPaging = False

        GridView2.HeaderRow.Style.Add("background-color", "#FFFFFF")

        For i As Integer = 0 To GridView2.HeaderRow.Cells.Count - 1
            GridView2.HeaderRow.Cells(i).Style.Add("background-color", "#df5015")
        Next

        VerifyRenderingInServerForm(GridView2)
        GridView2.RenderControl(htw)
        Response.Write(sw.ToString())
        Response.[End]()
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As System.Web.UI.Control)
        ' Verifies that the control is rendered 
        ' No code required here. 
    End Sub
End Class
