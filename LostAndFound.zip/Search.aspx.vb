Imports System.Data.SqlClient
Imports System.Data

Partial Class Search
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("UserName") = "" Or (Session("SecurityGroup") <> 1 And Session("SecurityGroup") <> 10) Then Response.Redirect("Login.aspx")

        If Not Page.IsPostBack Then
            If Request.QueryString("Display") = "no" Then
                Me.pnlSearch.Visible = False
            End If
            If Request.QueryString("ID") <> "" Then
                LoadRecord(Request.QueryString("ID"))
                sFillItemGridview(Request.QueryString("ID"))
                Exit Sub
            End If
            Me.cboColor.Items.Insert(0, "")
            Me.txtFromDate.Text = String.Format("{0:d}", DateAdd(DateInterval.Day, -7, Now()))
            Me.txtToDate.Text = String.Format("{0:d}", Now())
        End If

        Me.pnlFound.Visible = False

    End Sub

    Private Sub LoadRecord(ByVal iID As Integer)
        Dim sBase As String

        sBase = ""
        'Load the record
        sSQL = "SELECT * FROM dbo.tblFound WHERE ID = " & iID
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        Do While dr.Read()

            If Not IsDBNull(dr("FoundDate")) Then
                Me.txtFoundDate.Text = String.Format("{0:d}", dr("FoundDate"))
            End If
            If Not IsDBNull(dr("RouteNo")) Then
                Me.txtRoute.Text = dr("RouteNo").ToString()
            End If
            If Not IsDBNull(dr("BusNo")) Then
                Me.txtBusNumber.Text = dr("BusNo").ToString()
            End If
            If Not IsDBNull(dr("BadgeNumber")) Then
                Me.txtBadgeNumber.Text = dr("BadgeNumber").ToString()
            End If
            If Not IsDBNull(dr("EnteredBy")) Then
                Me.txtEnteredBy.Text = dr("EnteredBy").ToString()
            End If
            If Not IsDBNull(dr("EnteredDate")) Then
                Me.txtEnteredDate.Text = String.Format("{0:d}", dr("EnteredDate"))
            End If
            If Not IsDBNull(dr("ReceivedDate")) Then
                Me.txtReceivedDate.Text = String.Format("{0:d}", dr("ReceivedDate"))
            End If
            If Not IsDBNull(dr("ReceivedBy")) Then
                Me.txtReceivedBy.Text = dr("ReceivedBy").ToString()
            End If
            If Not IsDBNull(dr("ClaimedDate")) Then
                Me.txtClaimed.Text = String.Format("{0:d}", dr("ClaimedDate"))
            End If
            If Not IsDBNull(dr("ReleasedBy")) Then
                Me.txtReleasedBy.Text = dr("ReleasedBy").ToString()
            End If
            If Not IsDBNull(dr("Name")) Then
                Me.txtName.Text = dr("Name").ToString()
            End If
            If Not IsDBNull(dr("Address")) Then
                Me.txtAddress.Text = dr("Address").ToString()
            End If
            If Not IsDBNull(dr("City")) Then
                Me.txtCity.Text = dr("City").ToString()
            End If
            If Not IsDBNull(dr("State")) Then
                Me.txtState.Text = dr("State").ToString()
            End If
            If Not IsDBNull(dr("ZIP")) Then
                Me.txtZIP.Text = dr("ZIP").ToString()
            End If
            If Not IsDBNull(dr("Phone")) Then
                Me.txtPhone.Text = dr("Phone").ToString()
            End If
            If Not IsDBNull(dr("Notes")) Then
                Me.txtNotes.Text = dr("Notes").ToString()
            End If
            sBase = dr("Base")
        Loop
        Me.Found.InnerHtml = "<i class='fa fa-fw fa-tag'></i>Found at <b>" & sBase & "</b> Base -  Ticket# <span style='color:#ff6500'>" & iID & "</span>"

        oConn.Close()
        oComm = Nothing


    End Sub
    Private Sub sFillGridview()

        sSQL = "SELECT * FROM vwSearchList WHERE FoundDate BETWEEN '" & Me.txtFromDate.Text & "' AND '" & Me.txtToDate.Text & "'"

        Me.txtSQL.Text = sSQL

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()
        Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordList")

        Dim RcdCount As String
        RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

        'Check for returned records
        If RcdCount = 0 Then
            gvUnclaimedItems.Visible = False
        Else
            gvUnclaimedItems.Visible = True
            gvUnclaimedItems.DataSource = oDataSet.Tables.Item("dtRecordList")
            gvUnclaimedItems.DataBind()
        End If

        oConn.Close()
        oComm = Nothing

    End Sub


    Private Sub sFillItemGridview(ByVal iID As Integer)

        sSQL = "SELECT * FROM dbo.vwItemsClaimed WHERE FoundID =" & iID & ""

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()
        Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordList")

        Dim RcdCount As String
        RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

        'Check for returned records
        If RcdCount = 0 Then
            Me.pnlFound.Visible = False
        Else
            Me.pnlFound.Visible = True
            gvItemsFound.DataSource = oDataSet.Tables.Item("dtRecordList")
            gvItemsFound.DataBind()
        End If

    End Sub

    Protected Sub gvUnclaimedItems_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvUnclaimedItems.Sorting
        'Sort the datagrid
        SortGrid(e.SortExpression)

    End Sub

    Private Sub SortGrid(ByVal sSortField As String)

        'Sort function used to sort the data in the datagrid
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")

        Dim DS As DataSet
        Dim oReader As SqlDataAdapter

        oReader = New SqlDataAdapter(txtSQL.Text, sConn)

        DS = New DataSet
        oReader.Fill(DS, "LoadRecords")

        Dim Source As DataView = DS.Tables("LoadRecords").DefaultView
        Source.Sort = sSortField

        gvUnclaimedItems.DataSource = Source
        gvUnclaimedItems.DataBind()

    End Sub
    Sub GridPageChange(ByVal sender As Object, ByVal e As GridViewPageEventArgs)

        'Function used to page datagrid
        gvUnclaimedItems.PageIndex = e.NewPageIndex

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)

        oConn.Open()

        'Use the SQL staement stored in the txtSQL textbox
        Dim oAdapter As New SqlDataAdapter(txtSQL.Text, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordList")

        Dim RcdCount As String
        RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

        If RcdCount = 0 Then
            gvUnclaimedItems.Visible = False
        Else
            gvUnclaimedItems.Visible = True
            gvUnclaimedItems.DataSource = oDataSet.Tables.Item("dtRecordList")
            gvUnclaimedItems.DataBind()
        End If
    End Sub

    Protected Sub cboTagNo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboTagNo.SelectedIndexChanged

        LoadRecord(cboTagNo.SelectedValue)
        sFillItemGridview(cboTagNo.SelectedValue)

    End Sub
    Protected Sub toggle_Click(sender As Object, e As EventArgs) Handles toggle.Click
        If Me.pnlSearch.Visible = False Then
            Me.pnlSearch.Visible = True
        Else
            Me.pnlSearch.Visible = False
        End If
    End Sub

    Protected Sub cmdGoSearch_Click(sender As Object, e As EventArgs) Handles cmdGoSearch.Click
        Dim sCriteria As String
        Dim dDateFrom As Date
        Dim dDateTo As Date
        Dim MyItem As ListItem
        Dim sText As String

        sCriteria = ""
        sText = ""
        If Me.txtFromDate.Text = "" Or Me.txtToDate.Text = "" Then
            dDateFrom = String.Format("{0:d}", CDate(DateAdd(DateInterval.Day, -90, Now())))
            dDateTo = String.Format("{0:d}", Now())
            sCriteria = "FoundDate BETWEEN '" & dDateFrom & "' AND '" & dDateTo & "' AND "
        Else
            dDateFrom = CDate(Me.txtFromDate.Text)
            dDateTo = CDate(Me.txtToDate.Text)
            sCriteria = "FoundDate BETWEEN '" & dDateFrom & "' AND '" & dDateTo & "' AND "
        End If

        If Me.txtDescription.Text <> "" Then
            sCriteria = sCriteria & "Description LIKE '%" & Trim(Me.txtDescription.Text) & "%' AND "
        End If

        If Me.txtRouteNo.Text <> "" Then
            sCriteria = sCriteria & "RouteNo = " & Trim(Me.txtRouteNo.Text) & " AND "
        End If

        If Me.txtBusNo.Text <> "" Then
            sCriteria = sCriteria & "BusNo = " & Trim(Me.txtBusNo.Text) & " AND "
        End If

        If Me.txtMake.Text <> "" Then
            sCriteria = sCriteria & "Make = '" & Trim(Me.txtMake.Text) & "' AND "
        End If

        If Me.cboColor.SelectedIndex <> 0 Then
            sCriteria = sCriteria & "Color = '" & Trim(Me.cboColor.SelectedItem.Value) & "' AND "
        End If

        'If Me.txtSerial.Text <> "" Then
        '    sCriteria = sCriteria & "Serial = '" & Trim(Me.txtSerial.Text) & "' AND "
        'End If

        If Me.cboBase.SelectedIndex <> 0 Then
            sCriteria = sCriteria & "Base = '" & Me.cboBase.SelectedItem.Value & "' AND "
        End If

        txtSQL.Text = ""
        For Each MyItem In CheckBoxList1.Items
            If MyItem.Selected = True Then
                sText = sText & "'" & MyItem.Text & "', "
            End If
        Next

        If sText <> Nothing Then
            sText = Left(sText, Len(sText) - 2)
            sCriteria = sCriteria & "ItemCategory IN (" & sText & ") AND "
        End If

        sSQL = "SELECT * FROM dbo.vwSearchList WHERE " & sCriteria

        sSQL = Left(sSQL, Len(sSQL) - 5) & " ORDER BY FoundDate DESC"

        Me.txtSQL.Text = sSQL

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStrLostAndFound")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()
        Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordSearchList")

        Dim RcdCount As String
        RcdCount = oDataSet.Tables("dtRecordSearchList").Rows.Count.ToString()

        'Check for returned records
        If RcdCount = 0 Then
            gvUnclaimedItems.Visible = False
        Else
            gvUnclaimedItems.Visible = True
            gvUnclaimedItems.DataSource = oDataSet.Tables.Item("dtRecordSearchList")
            gvUnclaimedItems.DataBind()
        End If
        Me.pnlSearch.Visible = False

    End Sub

End Class
