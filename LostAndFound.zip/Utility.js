
    function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }

    function openclose() {
        var clickbutton = document.getElementById('ContentPlaceHolder1_toggle');
        clickbutton.click();
    }

    function OpenItemCategoryReport() {
        var objWin, varURL;
        var varStartDate;
        var varEndDate;
        var varItemCategoryID;
        varStartDate = document.getElementById('ContentPlaceHolder1_txtItemStartDate').value;
        varEndDate = document.getElementById('ContentPlaceHolder1_txtItemEndDate').value;
        var varSelectedObj = document.getElementById('ContentPlaceHolder1_cboItems');
        var varSelectedValue = varSelectedObj.options[varSelectedObj.selectedIndex].value;
        varURL = 'ItemCategoryReport.aspx?StartDate=' + varStartDate + '&EndDate=' + varEndDate + '&ItemCategoryID=' + varSelectedValue;
        objWin = window.open(varURL, '', 'left=200,top=100,toolbar=false,status=false,directories=false,menubar=false,scrollbars=yes,resizable=yes,copyhistory=false,width=800,height=500');
    }

    function OpenDailyReport() {
        var objWin, varURL;
        var varStartDate;
        varStartDate = document.getElementById('ContentPlaceHolder1_txtReportStartDate').value;
        varBase = document.getElementById('ContentPlaceHolder1_cboReportBase').value;
        varURL = 'DailyFoundReport.aspx?StartDate=' + varStartDate + '&Base=' + varBase;
        objWin = window.open(varURL, '', 'left=200,top=100,toolbar=false,status=false,directories=false,menubar=false,scrollbars=yes,resizable=yes,copyhistory=false,width=800,height=500');
    }

    function OpenClaimedReport() {
        var objWin, varURL;
        var varStartDate;
        varStartDate = document.getElementById('ContentPlaceHolder1_txtClaimReportStartDate').value;
        var varEndDate;
        varEndDate = document.getElementById('ContentPlaceHolder1_txtClaimReportEndDate').value;
        varBase = document.getElementById('ContentPlaceHolder1_cboClaimedReportBase').value;
        varURL = 'ClaimedReport.aspx?StartDate=' + varStartDate + '&EndDate=' + varEndDate + '&Base=' + varBase;
        objWin = window.open(varURL, '', 'left=200,top=100,toolbar=false,status=false,directories=false,menubar=false,scrollbars=yes,resizable=yes,copyhistory=false,width=800,height=500');
    }

    function OpenCashReport() {
        var objWin, varURL;
        var varStartDate, varEndDate;
        varStartDate = document.getElementById('ContentPlaceHolder1_txtStartDate').value;
        varEndDate = document.getElementById('ContentPlaceHolder1_txtEndDate').value;
        varURL = 'CashReport.aspx?StartDate=' + varStartDate + '&EndDate=' + varEndDate;
        objWin = window.open(varURL, '', 'left=200,top=100,toolbar=false,status=false,directories=false,menubar=false,scrollbars=yes,resizable=yes,copyhistory=false,width=800,height=500');
    }
    function OpenClaimedCashReport() {
        var objWin, varURL;
        var varStartDate, varEndDate;
        varStartDate = document.getElementById('ContentPlaceHolder1_txtClaimedCashStartDate').value;
        varEndDate = document.getElementById('ContentPlaceHolder1_txtClaimedCashEndDate').value;
        varURL = 'ClaimedCashReport.aspx?StartDate=' + varStartDate + '&EndDate=' + varEndDate;
        objWin = window.open(varURL, '', 'left=200,top=100,toolbar=false,status=false,directories=false,menubar=false,scrollbars=yes,resizable=yes,copyhistory=false,width=800,height=500');
    }
    function ReceivedItem() {
        var now = new Date();
        var curr_date = now.getDate();
        var curr_month = now.getMonth();
        curr_month++;
        var curr_year = now.getFullYear();

        document.getElementById('ContentPlaceHolder1_txtReceivedBy').value = document.getElementById('ContentPlaceHolder1_hfUserName').value;
        document.getElementById('ContentPlaceHolder1_txtReceivedDate').value = (curr_month + "/" + curr_date + "/" + curr_year);
    }
    function ClaimedItem() {
        var now = new Date();
        var curr_date = now.getDate();
        var curr_month = now.getMonth();
        curr_month++;
        var curr_year = now.getFullYear();

        document.getElementById('ContentPlaceHolder1_txtReleasedBy').value = document.getElementById('ContentPlaceHolder1_hfUsername').value;
        document.getElementById('ContentPlaceHolder1_txtClaimed').value = (curr_month + "/" + curr_date + "/" + curr_year);
    }    
    function getPassword() {
        var textValOldPass = document.getElementById('txtOldPass').value;
        var textValNewPass = document.getElementById('txtNewPass').value;
        var textValConfPass = document.getElementById('txtConfirm').value;

        if (!textValOldPass.match(/\S/) || !textValNewPass.match(/\S/) || !textValConfPass.match(/\S/)) {
            alert("All three fields must be filled in");
            return false;
        }
        else {
            var clickbutton = document.getElementById('cmdPassword');
            clickbutton.click();
            return true;
        }   
    }
    function getLogout() {
        var clickbutton = document.getElementById('cmdLogout');
        clickbutton.click();
    }
    function getGoFilter() {
        var clickbutton = document.getElementById('ContentPlaceHolder1_cmdGo');
        clickbutton.click();
    }
    function getSaveBtn() {
        var clickbutton = document.getElementById('ContentPlaceHolder1_btnSaveDetail');
        clickbutton.click();
    }
    function getAddItem() {
        var clickbutton = document.getElementById('ContentPlaceHolder1_cmdAdd');
        clickbutton.click();
    }
    function getFoundSave() {
        var ddlBase = document.getElementById('ContentPlaceHolder1_cboBase');
        if (ddlBase.value == "Select Base...") {
            alert("Please select a Base!");
            document.getElementById("ContentPlaceHolder1_cboBase").focus();
            return false;
        }        
        var clickbutton = document.getElementById('ContentPlaceHolder1_cmdFoundSave');
        clickbutton.click();
    }
    function getLostSave() {
        var clickbutton = document.getElementById('ContentPlaceHolder1_cmdLostSave');
        clickbutton.click();
    }
    function getRecievedSave() {
        var clickbutton = document.getElementById('ContentPlaceHolder1_cmdReceivedSave');
        clickbutton.click();
    }
    function getGoSearch() {
        var clickbutton = document.getElementById('ContentPlaceHolder1_cmdGoSearch');
        clickbutton.click();
    }	
    function startspellcheck() {
		if (document.forms[0].length > 0) {
			var field = document.forms[0];
			for (i = 0; i < field.length; i++) {
			if (field.elements[i].type == "textarea") {
				fieldname=document.forms[0].elements[i].name;
				text = document.forms[0].elements[i].value;
				if (text != "") {
					spellcheck(text, fieldname);
				}
			}
		} 
		}
		alert("Spell Check Complete!");
	}

	function spellcheck(text, fieldname) {
		oShell= new ActiveXObject("WScript.Shell");
		oWord= new ActiveXObject("Word.Application");
		oWord.Visible= false;
		oWord.Documents.Add();
		oWord.Selection.TypeText(text);
		oWord.ActiveDocument.CheckSpelling();
		oWord.Selection.WholeStory();
		strtext=oWord.Selection.Text;
		oWord.ActiveDocument.Close(0);
		oWord.Quit();
		fieldname = eval("document.forms[0]." + fieldname );
		fieldname.value = strtext;
	} 
		
	function OpenDetail(prmID)
	{
		window.location='WorkSheet.aspx?ID=' + prmID
	}
		
	function OpenViewMemo()
	{
	var objWin, varURL, varID
	varURL = 'MemoReport.aspx';
	objWin = window.open(varURL,'','left=200,top=100,toolbar=false,status=false,directories=false,menubar=false,scrollbars=yes,resizable=yes,copyhistory=false,width=625,height=500');
	}
		
	function EmailRecord()
	{
	var objWin, varURL
	varURL = 'EmailRecord.aspx?'
	objWin = window.open(varURL,'','left=200,top=100,toolbar=false,status=false,directories=false,menubar=false,scrollbars=yes,resizable=yes,copyhistory=false,width=360,height=370');
	}
	function DoBlur(fld) {
    fld.className='normalfld';
    }

    function DoFocus(fld) {
    fld.className = 'focusfld';
    }
        
    function GetDescription() {
    alert('Hit Me!');
    }

     